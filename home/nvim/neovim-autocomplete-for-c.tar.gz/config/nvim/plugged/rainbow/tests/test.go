typoo
(typoo)

client := &http.Client{}
