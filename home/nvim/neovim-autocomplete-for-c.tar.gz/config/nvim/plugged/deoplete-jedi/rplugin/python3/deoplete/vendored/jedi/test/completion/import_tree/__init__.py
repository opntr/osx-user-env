a = ''

from . import invisible_pkg

the_pkg = invisible_pkg

invisible_pkg = 1
