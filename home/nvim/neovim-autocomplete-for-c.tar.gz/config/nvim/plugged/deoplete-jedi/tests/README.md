# For deoplete-jedi test files

```bash
$ nvim -u ./tests/jedi-deoplete.vim tests/test-jedi.py
```

in nvim,

```vim
:UpdateRemotePlugins
:quit
```

again,

```bash
$ nvim -u ./tests/jedi-deoplete.vim tests/test-jedi.py
```

test it.
